package com.example.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import com.example.models.userEntity;

@Repository
public interface userRepository extends CrudRepository<userEntity, Long> {

    @Query("select u from userEntity u where u.email = ?1") // Se puede convertir en procedimiento almacenado
    Optional<userEntity> getEmail(String email);
}