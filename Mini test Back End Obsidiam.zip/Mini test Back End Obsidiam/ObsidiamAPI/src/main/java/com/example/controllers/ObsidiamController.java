package com.example.controllers;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.controllers.request.createUserDTO;
import com.example.models.enumerationRole;
import com.example.models.rolEntity;
import com.example.models.userEntity;
import com.example.repositories.userRepository;

import jakarta.validation.Valid;
import lombok.Delegate;

@RestController
public class ObsidiamController {

    @Autowired
    private PasswordEncoder passwordEncoder; // Inyección de dependencia

    @Autowired
    private userRepository userRepository; // Inyección de dependencia

    @PostMapping("/createUser") // método para crear usuarios, no se necesita token para utilizarlo
    public ResponseEntity<?> createUser(@Valid @RequestBody createUserDTO createUserDTO) {

        java.util.Set<rolEntity> roles = createUserDTO.getRoles().stream().map(
                rol -> rolEntity.builder()
                        .name(enumerationRole.valueOf(rol))
                        .build())
                .collect(Collectors.toSet());

        userEntity user = userEntity.builder()
                .email(createUserDTO.getEmail())
                .password(passwordEncoder.encode(createUserDTO.getPassword()))
                .rol(roles)
                .build();

        userRepository.save(user);
        return ResponseEntity.ok(user);
    }

    @GetMapping("/getUser") // método para leer un usuario, se necesita token para utilizarlo
    public ResponseEntity<?> getUser(@RequestParam String id) {
        Optional<userEntity> user = userRepository.findById(Long.parseLong(id));
        if (user.isPresent()) {
            userEntity userWithoutPassword = user.get();
            userWithoutPassword.setPassword(null); // No se muestra la contraseña del usuario
            return ResponseEntity.ok(userWithoutPassword);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "El usuario con el id " + id + " no fue encontrado");
        }
    }

    @GetMapping("/getAllUsers") // método para leer todos los usuarios, se necesita token para utilizarlo
    public ResponseEntity<?> getAllUsers() {
        List<userEntity> users = StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .collect(Collectors.toList());
        users.forEach(user -> user.setPassword(null)); // Set password to null for all users
        return ResponseEntity.ok(users);
    }

    // @PutMapping("/updateUser")
    // public ResponseEntity<?> updateUser(@RequestParam String id, @Valid
    // @RequestBody createUserDTO updateUserDTO) {
    // Optional<userEntity> userOptional =
    // userRepository.findById(Long.parseLong(id));
    // if(userOptional.isPresent()){
    // userEntity user = userOptional.get();

    // // Update the user details
    // user.setEmail(updateUserDTO.getEmail());
    // user.setPassword(passwordEncoder.encode(updateUserDTO.getPassword()));

    // java.util.Set<rolEntity> roles = updateUserDTO.getRoles().stream().map(
    // rol -> rolEntity.builder()
    // .name(enumerationRole.valueOf(rol))
    // .build())
    // .collect(Collectors.toSet());

    // user.setRol(roles);

    // userRepository.save(user);
    // user.setPassword(null); // Set password to null
    // return ResponseEntity.ok(user);
    // } else {
    // throw new RuntimeException("Usuario no encontrado para el id "+id);
    // }
    // }

    @DeleteMapping("/deleteUser") // método para eliminar un usuario, se necesita token para utilizarlo
    public ResponseEntity<?> deleteUser(@RequestParam String id) {
        try {
            userRepository.deleteById(Long.parseLong(id));
            return ResponseEntity.ok("Se borró el usuario ".concat(id));
        } catch (EmptyResultDataAccessException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "El usuario con el id " + id + " no fue encontrado");
        }
    }

}
