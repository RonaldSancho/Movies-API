package com.example.security.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;
import java.util.function.Function;

@Component
@Slf4j
public class utils {

    @Value("${jwt.secret.key}") // se obtiene la key generada
    private String secretKey;

    @Value("${jwt.time.expiration}") // se obtiene el tiempo establecido
    private String timeExpiration;

    @SuppressWarnings("deprecation")
    public String createToken(String email) {
        return Jwts.builder() // Creación del Token
                .setSubject(email) // El token estará referido al email
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + Long.parseLong(timeExpiration.trim()))) // Expiración
                                                                                                             // del
                                                                                                             // Token
                                                                                                             // (60
                                                                                                             // minutos)
                .signWith(getSignatureKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    @SuppressWarnings("deprecation")
    public boolean TokenValid(String token) {
        try {
            Jwts.parser() // Validación del Toekn
                    .setSigningKey(getSignatureKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
            return true;
        } catch (Exception e) {
            log.error("El token es inválido, error: ".concat(e.getMessage()));
            return false;
        }
    }

    public String getEmailToken(String token) { // Se obtiene el Email
        return getClaim(token, Claims::getSubject);
    }

    public <t> t getClaim(String token, Function<Claims, t> claimsTFunction) {
        Claims claims = extractAllClaims(token);
        return claimsTFunction.apply(claims);
    }

    @SuppressWarnings("deprecation")
    public Claims extractAllClaims(String token) {
        return Jwts.parser()
                .setSigningKey(getSignatureKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public Key getSignatureKey() {
        byte[] keyBytes = Decoders.BASE64.decode(secretKey); // Decodificación del SecretKey
        return Keys.hmacShaKeyFor(keyBytes);
    }
}