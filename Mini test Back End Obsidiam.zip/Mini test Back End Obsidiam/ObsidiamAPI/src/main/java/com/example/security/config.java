package com.example.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.security.filters.jwtAuth;
import com.example.security.filters.jwtAutho;
import com.example.security.jwt.utils;
import com.example.service.userService;

@Configuration
public class config {

    @Autowired
    userService userService; // Inyección de dependencia

    @Autowired
    utils utils; // Inyección de dependencia

    @Autowired
    jwtAutho jwtAutho; // Inyección de dependencia

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity, AuthenticationManager authenticationManager)
            throws Exception {

        jwtAuth auth = new jwtAuth(utils); // Se crea una instacia
        auth.setAuthenticationManager(authenticationManager);

        return httpSecurity
                .csrf(config -> config.disable())
                .authorizeHttpRequests(authorize -> {
                    authorize.requestMatchers("/createUser").permitAll(); // Solo el método createUser no necesita
                                                                          // Autorización
                    authorize.anyRequest().authenticated();
                })
                .sessionManagement(session -> {
                    session.sessionCreationPolicy(SessionCreationPolicy.STATELESS);
                })
                .addFilter(auth)
                .addFilterBefore(jwtAutho, UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    @SuppressWarnings("removal")
    @Bean
    AuthenticationManager authenticationManager(HttpSecurity httpSecurity, PasswordEncoder passwordEncoder)
            throws Exception {
        return httpSecurity.getSharedObject(AuthenticationManagerBuilder.class)
                .userDetailsService(userService)
                .passwordEncoder(passwordEncoder)
                .and().build();
    }

    @Bean
    PasswordEncoder passwordEncoder() { // Implementación de seguridad encriptando las contraseñas
        return new BCryptPasswordEncoder();
    }

}
