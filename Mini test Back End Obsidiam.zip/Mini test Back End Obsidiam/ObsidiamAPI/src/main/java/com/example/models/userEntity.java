package com.example.models;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "user")

public class userEntity {
    @Id // Se indica que se espera un ID
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Se genera de forma automatica el ID
    private Long id;

    @Email // Se indica que se espera un email
    @NotBlank // No puede ser vacío
    @Size(max = 75) // El máximo de caracteres es de 75
    private String email;

    @NotBlank // No puede ser vacío
    private String password;

    @ManyToMany(fetch = FetchType.EAGER, targetEntity = rolEntity.class, cascade = CascadeType.PERSIST) // Se define la
                                                                                                        // relación
                                                                                                        // entre usuario
                                                                                                        // y roles
    @JoinTable(name = "user_rol", joinColumns = @JoinColumn(name = "userID"), inverseJoinColumns = @JoinColumn(name = "roleID"))
    private java.util.Set<rolEntity> rol;
}
