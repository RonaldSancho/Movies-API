package com.example.controllers.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class createUserDTO {
    @Email
    @NotBlank
    private String email;

    @NotBlank
    private String password;
    private java.util.Set<String> roles;
}
