package com.example.models;

public enum enumerationRole { // Se definen los roles que se utilizarán
    adminObsidiam,
    clientObsidiam
}
